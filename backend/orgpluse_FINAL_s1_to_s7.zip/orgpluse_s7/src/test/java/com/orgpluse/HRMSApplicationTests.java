package com.orgpluse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HRMSApplicationTests {

    @Test
    void contextLoads() {
    }

}
