package com.hrms.controllers;

import com.hrms.entities.Employee;
import com.hrms.response_wrapper.ResponseWrapper;
import com.hrms.services.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin")
@CrossOrigin("*")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    // POST /api/v1/admin/employees
    @PostMapping("/employees")
    public ResponseEntity<ResponseWrapper> addEmployee(@RequestBody Employee employee) {
        return employeeService.addEmployee(employee);
    }

    // PUT /api/v1/admin/employees/{id}
    @PutMapping("/employees/{id}")
    public ResponseEntity<ResponseWrapper> updateEmployee(@PathVariable Long id,
                                                           @RequestBody Employee employee) {
        return employeeService.updateEmployee(id, employee);
    }

    // DELETE /api/v1/admin/employees/{id}
    @DeleteMapping("/employees/{id}")
    public ResponseEntity<ResponseWrapper> deleteEmployee(@PathVariable Long id) {
        return employeeService.deleteEmployee(id);
    }

    // GET /api/v1/admin/employees/{id}
    @GetMapping("/employees/{id}")
    public ResponseEntity<ResponseWrapper> getEmployeeById(@PathVariable Long id) {
        return employeeService.getEmployeeById(id);
    }

    // GET /api/v1/admin/employees?search=&sortBy=&sortDirection=
    @GetMapping("/employees")
    public ResponseEntity<ResponseWrapper> getAllEmployees(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String sortBy,
            @RequestParam(required = false) String sortDirection) {
        return employeeService.getAllEmployees(search, sortBy, sortDirection);
    }

    // GET /api/v1/admin/employees/filter?search=&departmentId=&designationId=
    //                                   &branchId=&status=&gender=&managerId=
    //                                   &sortBy=&sortDirection=
    @GetMapping("/employees/filter")
    public ResponseEntity<ResponseWrapper> filterEmployees(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) Long departmentId,
            @RequestParam(required = false) Long designationId,
            @RequestParam(required = false) Long branchId,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String gender,
            @RequestParam(required = false) Long managerId,
            @RequestParam(required = false) String sortBy,
            @RequestParam(required = false) String sortDirection) {
        return employeeService.filterEmployees(
                search, departmentId, designationId, branchId,
                status, gender, managerId, sortBy, sortDirection);
    }

}
