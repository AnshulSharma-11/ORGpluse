package com.hrms.controllers;

import com.hrms.entities.Help;
import com.hrms.response_wrapper.ResponseWrapper;
import com.hrms.services.HelpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin")
@CrossOrigin("*")
public class HelpController {

    @Autowired
    private HelpService helpService;

    // POST /api/v1/admin/help
    @PostMapping("/help")
    public ResponseEntity<ResponseWrapper> addHelp(@RequestBody Help help) {
        return helpService.addHelp(help);
    }

    // PUT /api/v1/admin/help/{id}
    @PutMapping("/help/{id}")
    public ResponseEntity<ResponseWrapper> updateHelp(@PathVariable Long id,
                                                       @RequestBody Help help) {
        return helpService.updateHelp(id, help);
    }

    // DELETE /api/v1/admin/help/{id}
    @DeleteMapping("/help/{id}")
    public ResponseEntity<ResponseWrapper> deleteHelp(@PathVariable Long id) {
        return helpService.deleteHelp(id);
    }

    // GET /api/v1/admin/help/{id}
    @GetMapping("/help/{id}")
    public ResponseEntity<ResponseWrapper> getHelpById(@PathVariable Long id) {
        return helpService.getHelpById(id);
    }

    // GET /api/v1/admin/help?search=&sortBy=&sortDirection=
    @GetMapping("/help")
    public ResponseEntity<ResponseWrapper> getAllHelp(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String sortBy,
            @RequestParam(required = false) String sortDirection) {
        return helpService.getAllHelp(search, sortBy, sortDirection);
    }

    // GET /api/v1/admin/help/filter?requestType=&status=&priority=
    //                             &employeeId=&assignedTo=
    //                             &currentDepartmentId=&requestedDepartmentId=
    //                             &search=&sortBy=&sortDirection=
    @GetMapping("/help/filter")
    public ResponseEntity<ResponseWrapper> filterHelp(
            @RequestParam(required = false) String requestType,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String priority,
            @RequestParam(required = false) Long employeeId,
            @RequestParam(required = false) Long assignedTo,
            @RequestParam(required = false) Long currentDepartmentId,
            @RequestParam(required = false) Long requestedDepartmentId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String sortBy,
            @RequestParam(required = false) String sortDirection) {
        return helpService.filterHelp(requestType, status, priority,
                employeeId, assignedTo, currentDepartmentId, requestedDepartmentId,
                search, sortBy, sortDirection);
    }

}
