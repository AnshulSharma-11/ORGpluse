package com.hrms.repositories;

import com.hrms.entities.Designation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface DesignationRepository extends JpaRepository<Designation, Long>,
        JpaSpecificationExecutor<Designation> {
}
