package com.hrms.repositories;

import com.hrms.entities.EmployeeJobHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeJobHistoryRepository extends JpaRepository<EmployeeJobHistory, Long>,
        JpaSpecificationExecutor<EmployeeJobHistory> {
}
