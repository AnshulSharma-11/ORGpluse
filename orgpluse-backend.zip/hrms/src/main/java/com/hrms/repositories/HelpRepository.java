package com.hrms.repositories;

import com.hrms.entities.Help;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface HelpRepository extends JpaRepository<Help, Long>,
        JpaSpecificationExecutor<Help> {
}
