package com.hrms.repositories;

import com.hrms.entities.PayrollRun;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface PayrollRunRepository extends JpaRepository<PayrollRun, Long>,
        JpaSpecificationExecutor<PayrollRun> {
}
