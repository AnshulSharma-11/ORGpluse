package com.hrms.repositories;

import com.hrms.entities.PerformanceReview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface PerformanceReviewRepository extends JpaRepository<PerformanceReview, Long>,
        JpaSpecificationExecutor<PerformanceReview> {
}
